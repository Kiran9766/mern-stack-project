import React from 'react';
import Dashboard from './pages/Dashboard';

function App() {
  return (
    <div className="App">
      <h1>Transaction Dashboard</h1>
      <Dashboard />
    </div>
  );
}

export default App;
